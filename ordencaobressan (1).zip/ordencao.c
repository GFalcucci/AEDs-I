#include "ordenacao.h"

void trocar(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void bubble_sort(int* inicio, int* fim) {
    for (int* i = inicio; i < fim - 1; i++) {
        for (int* j = inicio; j < fim - (i - inicio) - 1; j++) {
            if (*j > *(j + 1)) {
                trocar(j, j + 1);
            }
        }
    }
}

void selection_sort(int* inicio, int* fim) {
    for (int* i = inicio; i < fim - 1; i++) {
        int* menor = i;
        for (int* j = i + 1; j < fim; j++) {
            if (*j < *menor) {
                menor = j;
            }
        }
        trocar(i, menor);
    }
}

void insertion_sort(int* inicio, int* fim) {
    for (int* i = inicio + 1; i < fim; i++) {
        int* j = i;
        while (j > inicio && *(j - 1) > *j) {
            trocar(j, j - 1);
            j--;
        }
    }
}
