#ifndef ORDENACAO_H
#define ORDENACAO_H

void bubble_sort(int* inicio, int* fim);
void selection_sort(int* inicio, int* fim);
void insertion_sort(int* inicio, int* fim);

#endif
